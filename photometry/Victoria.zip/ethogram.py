#https://matplotlib.org/stable/gallery/subplots_axes_and_figures/subplots_demo.html
#https://stackoverflow.com/questions/11190735/python-matplotlib-superimpose-scatter-plots


#TO FIX LATER: ENSURE CHANNELS ARE ALL SAME LENGTH
#FIX FRAME RATE OF PHOTO TO MATCH FRAME RATE OF VIDEO

start=60
length_s=300
fps_behav=30
fps_photo=20
#Which roi/fiber signal do you want to plot (0-2)
z=0


#type 'pip install package_name' into terminal if these packages arent arent already installed
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from numpy import exp
import numpy as np
import warnings
# from math import exp
    
def main():
    global fps_behav, fps_photo, length_s, start, z

    #Extract variables from csv file
    #etho_raw=pd.read_csv("D:\Pup Block 1\Day1-09202022\\7\ODOR\Raw data-MeP-CRFR2photo_pupblock1-Trial     9.txt")
    #get video name col [[1] row [18]]

    #re-call file
    etho_raw=pd.read_excel("D:\MeP-CRFR2photo_pupblock1\Export Files\Raw data-MeP-CRFR2photo_pupblock1-Trial     9 (2).xlsx", header=[32], skiprows=[33])
    
    behaviors=[]
    for i in etho_raw:
        behaviors.append(i)
    behavior=behaviors[7:-1] #only registers columns 8 to the second to last as behaviors


    # video_duration=round(len(etho_raw)/fps_etho)
    # data_offset=video_duration-recording duration
    # d=recording_duration-data_offset
    # behav_crop=data_offset*fps_behav
    # behav_cut=etho_raw[behav_crop:]
    # fig, ax=plt.subplots(2)

    plt.imshow(etho_raw[behavior[17]], aspect='auto', interpolation='none', origin='lower')#suggest=True, show=False)
    plt.style.use('seaborn')              
    # ax[1].set_figheight(0.6)
    plt.show() 
main()
    