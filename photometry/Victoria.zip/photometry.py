#https://matplotlib.org/stable/gallery/subplots_axes_and_figures/subplots_demo.html
#https://stackoverflow.com/questions/11190735/python-matplotlib-superimpose-scatter-plots


#TO FIX LATER: ENSURE CHANNELS ARE ALL SAME LENGTH
#FIX FRAME RATE OF PHOTO TO MATCH FRAME RATE OF VIDEO

start=60
length_s=300
fps_behav=30
fps_photo=20
#Which roi/fiber signal do you want to plot (0-2)
z=0


import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from numpy import exp
import numpy as np
import warnings
# from math import exp
    

def split(fp_raw,z, fps_photo):
    led=fp_raw['LedState']

    roi=[]
    #Extract column headers from CSV to give user options
    for i in fp_raw:
        if 'Region' in i:
            roi.append(i)
        else:
            continue
    roi_=roi[z]
    trace=fp_raw[roi_][1:]
    # print(trace)
    _470=[]
    _410=[]
    for i, j in zip(led,trace):
        if (i==6):
            _470.append(j)
        else:
            _410.append(j)

    if len(_470)!=len(_410):
        if len(_470)>len(_410):
            _470.remove(_470[-1])
        elif len(_470)<len(_410):
            _410.remove(_410(-1))

    k=0
    frame=[]
    for i in _470:
        k+=1
        frame.append(k)

    time=[]
    for i in frame:
        j=i/fps_photo
        time.append(j)

    FP_data=pd.DataFrame({
            'Frames': frame,
            'Time': time, 
            '470': _470,
             '410': _410,
             })

    return FP_data

def exp2(x, a, b, c, d):
    return a*exp(b*x)+ c*exp(d*x)

def main():
    global fps_behav, fps_photo, length_s, start, z

    #Extract variables from csv file
    fp_raw=pd.read_csv("D:\Pup Block 1\Day1-09202022\8\Pup\\7_split2022-09-20T22_27_56.CSV")
    
    #Split columns and channels
    col=[]
    FP_data=split(fp_raw,z, fps_photo)
    for i in FP_data:
        col.append(i)
    frames=FP_data[col[0]]
    photo_time=FP_data[col[1]]
    _470=FP_data[col[2]] 
    _410=FP_data[col[3]] 


    #CALCULATIONS FOR BIEXPONENTIAL FIT
    popt, pcov=curve_fit(exp2,frames,_410,maxfev=1000000,p0=[0.01, 1e-7, 1e-5, 1e-9] )
    _410_fit1=exp2(frames,*popt)

    #RAW TRACE
    fig, ax=plt.subplots(2)
    ax[0].plot(frames,_470)
    ax[0].set_title('Raw 470')
    ax[0].set(xlabel='Frame #', ylabel=r'$\Delta$F/F')

    #BIEXPONENTIAL FIT
    ax[1].set_ylim([_410.min(), _410.max()])
    ax[1].plot(frames, _410)
    ax[1].plot(frames, _410_fit1, 'r') 
    ax[1].set_title('410 with biexponential fit')  #rationale: https://onlinelibrary.wiley.com/doi/10.1002/mma.7396
    ax[1].set(xlabel='Frame #', ylabel=r'$\Delta$F/F')
    
    ax[0].label_outer()

    plt.show()

    #410_fit2=

    #ROBUST FIT  %%figure out the python equivalent for robustfit()
    
    #Df/f 410 OVER 470
    # _410to470=(_470-lin_fit)/lin_fit
    # _470_scaled=fitlm(_410, _470)   
    # normalizedtrace=(_470-_410to470)

    # fig, ax=plt.subplots(4)
    # ax[1].plot(_470)
    # ax[1].plot(_410_fit2)

    # ax[2],plot(_410to470)

    # ax[3], plot(_470_scaled)



    # plt.plot(FP_data[col[0]], exp2(FP_data[col[0]], *popt), 'r-')
# plot(FP.data(:,3))
# temp_x = 1:length(FP.data); %note -- using a temporary x variable due to computational constraints in matlab
# temp_x = temp_x';
# FP.fit1 = fit(temp_x,FP.data(:,3),'exp2');

# # hold on
# # plot(FP.fit1(temp_x),'LineWidth',2)

# # title('415 data fit with biexponential')
# # xlabel('frame number')
# # ylabel('F (mean pixel value')
# # plt.figure(1)
# # a = plt.subplot(211)
# # r = 2**16/2
# # a.set_ylim([-r, r])
# a.set_xlabel('time [s]')
# a.set_ylabel('sample value [-]')
# x = np.arange(44100)/44100
# plt.plot(x, left)
# b = plt.subplot(212)
# b.set_xscale('log')
# b.set_xlabel('frequency [Hz]')
# b.set_ylabel('|amplitude|')
# plt.plot(lf)
# plt.savefig('sample-graph.png')

#RAW TRACE


#     temp_x=createList(1,len(_))
#     FP=[]
# #linearly scale fit to 470 data using robustfit

# FP_fit2 = robustfit(FP.fit1(temp_x),FP.data(:,2)); %scale using robust fit
# FP.lin_fit = FP.fit1(temp_x)*FP.fit2(2)+FP.fit2(1); %plot with robust fit


    
    # plt.show()


    
    # for j,i in zip(trace,led):
    #     if i==6:
    #         _470.append(j)
    #     if i==1:
    #         _410.append(j)
    # print(len(_470),len(_410))
    
    
main()




